# csce576_group6
Blackboard Functional Prototype

## Note:
Run this command to get a local web server to help eliminate weird compatibility issues.

`python3 -m http.server 8000`